typedef struct ES ES ;
struct ES
{

SDL_Surface *image;

SDL_Rect espos;



};


